# library(testthat)

# Run tests ---------------------------------------------------------------

# test_dir(path = "tests/testthat/")


options(testthat.progress.max_fails = 100)